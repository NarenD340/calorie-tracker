const CACHE_NAME = "calorie-tracker-v2";  // bump version
const FILES_TO_CACHE = [
  "index.html",                      // match manifest
  "manifest.json",
  "offline.html",
  "style.css",
  "script.js",
  "calorie icon_imresizer.png",      // fixed extra .png
  "https://cdn.jsdelivr.net/npm/chart.js",
  "calorie icon_imresizer2.png"                     // consistent path
];

// Install SW → cache files
self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log("Caching app files...");
      return cache.addAll(FILES_TO_CACHE);
    })
  );
});

// Activate SW → clean old caches
self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
});

// Fetch → serve cached files when offline
self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then((response) => {
      return (
        response ||
        fetch(event.request).catch(() => caches.match("offline.html"))
      );
    })
  );
});
