/* calorei.js - main app logic (uses localStorage) */

let baseFoodNutrients = {
  "dosai": { calories: 120, carbs: 16, protein: 3, fats: 5 },
  "idly": { calories: 59, carbs: 12, protein: 1, fats: 0.5 },
  "chicken": { calories_per_gram: 2, carbs: 0, protein: 0.25, fats: 0.05 },
  "rice": { calories_per_gram: 1.3, carbs: 0.45, protein: 0.043, fats: 0.004 },
  "ragi dosai": { calories: 100, carbs: 20, protein: 2, fats: 1 },
  "pongal": { calories: 319, carbs: 47, protein: 7, fats: 11 },
  "chappathi": { calories: 140, carbs: 23, protein: 4, fats: 2 }
};

const recommendedLimits = { calories: 2000, carbs: 300, protein: 50, fats: 70 };
let entries = JSON.parse(localStorage.getItem("entries")) || [];

/* storage helpers */
function saveReports(reports) { localStorage.setItem("reports", JSON.stringify(reports)); }
function loadReports()  { try { return JSON.parse(localStorage.getItem("reports")) || {}; } catch { return {}; } }
function saveCustomFoods(customFoods) { localStorage.setItem("customFoods", JSON.stringify(customFoods)); }
function loadCustomFoods() { try { return JSON.parse(localStorage.getItem("customFoods")) || {}; } catch { return {}; } }

/* foods initial */
let customFoods = loadCustomFoods();
let foodNutrients = { ...baseFoodNutrients, ...customFoods };

/* Populate select */
function populateFoodOptions() {
  const foodSelect = document.getElementById("food");
  if (!foodSelect) return;
  foodSelect.innerHTML = '<option value="">-- Choose a food --</option>';
  Object.keys(foodNutrients).sort().forEach(food => {
    foodSelect.innerHTML += `<option value="${food}">${food}</option>`;
  });
}

/* Entries */
function addFood() {
  const food = document.getElementById("food").value;
  const quantity = parseFloat(document.getElementById("quantity").value);
  if (!food || isNaN(quantity) || quantity <= 0) { alert("Please enter a valid food and quantity."); return; }
  const date = new Date().toISOString().split("T")[0];
  entries.push({ food, quantity, date });
  localStorage.setItem("entries", JSON.stringify(entries));
  displayEntries();
}

function displayEntries() {
  const container = document.getElementById("entries");
  if (!container) return;
  if (entries.length === 0) { container.innerHTML = "<h3>Entries:</h3><div class='card'>No entries yet.</div>"; return; }
  container.innerHTML = "<h3>Entries:</h3>";
  entries.forEach((entry, index) => {
    container.innerHTML += `
      <div class="entry">
        <span>${entry.quantity} × ${entry.food} <small style="opacity:0.6;">(${entry.date || ""})</small></span>
        <button onclick="removeEntry(${index})">Remove</button>
      </div>`;
  });
}

function removeEntry(index) {
  entries.splice(index, 1);
  localStorage.setItem("entries", JSON.stringify(entries));
  displayEntries();
}

/* Calculate and Save daily totals */
function showResults() {
  let totals = { calories: 0, carbs: 0, protein: 0, fats: 0 };
  const today = new Date().toISOString().split("T")[0];

  // --- Food entries ---
  entries.forEach(({ food, quantity, date }) => {
    if (date !== today) return;
    const item = foodNutrients[food];
    if (!item) return;

    if (item.calories_per_gram) {
      totals.calories += (item.calories_per_gram || item.calories) * quantity;
      totals.carbs   += (item.carbs   || 0) * quantity;
      totals.protein += (item.protein || 0) * quantity;
      totals.fats    += (item.fats    || 0) * quantity;
    } else {
      totals.calories += (item.calories || 0) * quantity;
      totals.carbs   += (item.carbs   || 0) * quantity;
      totals.protein += (item.protein || 0) * quantity;
      totals.fats    += (item.fats    || 0) * quantity;
    }
  });

  // --- Exercise entries ---
  let totalBurned = 0;
  (exerciseEntries || []).forEach(({ burned, date }) => {
    if (date === today) totalBurned += burned;
  });

  // Net calories
  const netCalories = totals.calories - totalBurned;

  // Save report including exercise
  const reports = loadReports();
  reports[today] = { ...totals, burned: totalBurned, net: netCalories };
  saveReports(reports);

  // --- Display results ---
  const results = document.getElementById("results");
  if (!results) return;

  const check = (val, lim) =>
    val > lim
      ? `<span style="color:#ff6b6b">${(val - lim).toFixed(2)} over</span>`
      : `<span style="color:#6bd26b">OK</span>`;

  results.innerHTML = `
    <h3>Today’s Report (${today})</h3>
    <strong>Calories Eaten:</strong> ${totals.calories.toFixed(2)} kcal ${check(totals.calories, recommendedLimits.calories)}<br>
    <strong>🔥 Calories Burned:</strong> ${totalBurned.toFixed(2)} kcal<br>
    <strong>⚖ Net Calories:</strong> ${netCalories.toFixed(2)} kcal<br><br>
    <strong>Carbs:</strong> ${totals.carbs.toFixed(2)} g ${check(totals.carbs, recommendedLimits.carbs)}<br>
    <strong>Protein:</strong> ${totals.protein.toFixed(2)} g ${check(totals.protein, recommendedLimits.protein)}<br>
    <strong>Fats:</strong> ${totals.fats.toFixed(2)} g ${check(totals.fats, recommendedLimits.fats)}
  `;

  // Draw the new macro charts
  drawCharts(totals.carbs, totals.protein, totals.fats);
}


/* Daily Report */
function showDailyReport() {
  showResults(); // reuse logic
}

/* Weekly Report */
function showWeeklyReport() {
  const results = document.getElementById("results");
  if (!results) return;

  // Ensure all entries have dates
  entries = entries.map(e => {
    if (!e.date) e.date = new Date().toISOString().split("T")[0];
    return e;
  });
  localStorage.setItem("entries", JSON.stringify(entries));

  let today = new Date();
  let start = new Date(today);
  start.setDate(today.getDate() - 6);

  let startStr = start.toISOString().split("T")[0];
  let endStr   = today.toISOString().split("T")[0];

  let weekTotals = { calories:0, burned:0, carbs:0, protein:0, fats:0 };
  let daysCount = 0;
  let output = "";

  for (let i = 6; i >= 0; i--) {
    let d = new Date(today);
    d.setDate(today.getDate() - i);
    let dateKey = d.toISOString().split("T")[0];

    // Food
    let dayEntries = entries.filter(e => e.date === dateKey);
    let dayTotals = { calories:0, carbs:0, protein:0, fats:0 };

    dayEntries.forEach(item => {
      let f = foodNutrients[item.food];
      if (!f) return;
      if (f.calories_per_gram) {
        dayTotals.calories += f.calories_per_gram * item.quantity;
        dayTotals.carbs += f.carbs * item.quantity;
        dayTotals.protein += f.protein * item.quantity;
        dayTotals.fats += f.fats * item.quantity;
      } else {
        dayTotals.calories += f.calories * item.quantity;
        dayTotals.carbs += f.carbs * item.quantity;
        dayTotals.protein += f.protein * item.quantity;
        dayTotals.fats += f.fats * item.quantity;
      }
    });

    // Exercises
    let burned = 0;
    (exerciseEntries || []).forEach(ex => {
      if (ex.date === dateKey) burned += ex.burned;
    });

    let net = dayTotals.calories - burned;

    weekTotals.calories += dayTotals.calories;
    weekTotals.burned   += burned;
    weekTotals.carbs    += dayTotals.carbs;
    weekTotals.protein  += dayTotals.protein;
    weekTotals.fats     += dayTotals.fats;

    daysCount++;

    output += `
      <div class="card">
        <strong>${dateKey}</strong><br>
        🍽 Calories: ${dayTotals.calories.toFixed(2)} kcal<br>
        🔥 Burned: ${burned.toFixed(2)} kcal<br>
        ⚖ Net: ${net.toFixed(2)} kcal<br>
        Carbs: ${dayTotals.carbs.toFixed(2)} g<br>
        Protein: ${dayTotals.protein.toFixed(2)} g<br>
        Fats: ${dayTotals.fats.toFixed(2)} g
      </div>
    `;
  }

  let avgCalories = daysCount ? (weekTotals.calories / daysCount).toFixed(2) : 0;

  results.innerHTML = `
    <h3>📊 Weekly Report</h3>
    <p><em>${startStr} → ${endStr}</em></p>
    <div class="card" style="background:#eef6ff">
      <strong>Totals</strong><br>
      🍽 Calories: ${weekTotals.calories.toFixed(2)} kcal<br>
      🔥 Burned: ${weekTotals.burned.toFixed(2)} kcal<br>
      ⚖ Net: ${(weekTotals.calories - weekTotals.burned).toFixed(2)} kcal<br>
      Carbs: ${weekTotals.carbs.toFixed(2)} g<br>
      Protein: ${weekTotals.protein.toFixed(2)} g<br>
      Fats: ${weekTotals.fats.toFixed(2)} g<br>
      <em>Avg Calories/Day: ${avgCalories}</em>
    </div>
    ${output}
  `;
}


/* pick Report */
function pickCustomDates() {
  // Ask user to pick start date
  let start = prompt("Enter Start Date (YYYY-MM-DD):");
  if (!start) return;

  // Ask user to pick end date
  let end = prompt("Enter End Date (YYYY-MM-DD):");
  if (!end) return;

  generateCustomReport(start, end);
}

function generateCustomReport(start, end) {
  const results = document.getElementById("results");
  if (!results) return;

  let output = "";
  let totals = { calories:0, carbs:0, protein:0, fats:0, burned:0 };
  let daysCount = 0;

  let startDate = new Date(start);
  let endDate = new Date(end);

  for (let d = new Date(startDate); d <= endDate; d.setDate(d.getDate() + 1)) {
    let dateKey = d.toISOString().split("T")[0];

    let dayEntries = entries.filter(e => e.date === dateKey);
    let exerciseDay = (exerciseEntries || []).filter(e => e.date === dateKey);

    if (dayEntries.length === 0 && exerciseDay.length === 0) continue;
    daysCount++;

    let dayTotals = { calories:0, carbs:0, protein:0, fats:0, burned:0 };
    let foodsHtml = "<ul>";

    // Food
    dayEntries.forEach(item => {
      let f = foodNutrients[item.food];
      if (!f) return;
      if (f.calories_per_gram) {
        dayTotals.calories += f.calories_per_gram * item.quantity;
        dayTotals.carbs += f.carbs * item.quantity;
        dayTotals.protein += f.protein * item.quantity;
        dayTotals.fats += f.fats * item.quantity;
      } else {
        dayTotals.calories += f.calories * item.quantity;
        dayTotals.carbs += f.carbs * item.quantity;
        dayTotals.protein += f.protein * item.quantity;
        dayTotals.fats += f.fats * item.quantity;
      }
      foodsHtml += `<li>${item.quantity} × ${item.food}</li>`;
    });

    // Exercise
    exerciseDay.forEach(ex => {
      dayTotals.burned += ex.burned;
    });

    foodsHtml += "</ul>";

    totals.calories += dayTotals.calories;
    totals.carbs    += dayTotals.carbs;
    totals.protein  += dayTotals.protein;
    totals.fats     += dayTotals.fats;
    totals.burned   += dayTotals.burned;

    output += `
      <div class="card">
        <strong>${dateKey}</strong><br>
        Calories: ${dayTotals.calories.toFixed(2)} kcal<br>
        Burned: ${dayTotals.burned.toFixed(2)} kcal<br>
        Carbs: ${dayTotals.carbs.toFixed(2)} g<br>
        Protein: ${dayTotals.protein.toFixed(2)} g<br>
        Fats: ${dayTotals.fats.toFixed(2)} g
        ${foodsHtml}
      </div>
    `;
  }

  let avgCalories = daysCount ? (totals.calories / daysCount).toFixed(2) : 0;

  results.innerHTML = `
    <h3>Custom Report</h3>
    <p><em>${start} → ${end}</em></p>
    <div class="card" style="background:rgba(0,0,0,0.3);">
      <strong>Totals</strong><br>
      Calories: ${totals.calories.toFixed(2)} kcal<br>
      Burned: ${totals.burned.toFixed(2)} kcal<br>
      Carbs: ${totals.carbs.toFixed(2)} g<br>
      Protein: ${totals.protein.toFixed(2)} g<br>
      Fats: ${totals.fats.toFixed(2)} g<br>
      <em>Average Calories/Day: ${avgCalories}</em>
    </div>
    ${output}
  `;
}


/* Custom food (remove via prompt) */
function removeFoodPrompt(){
  const keys = Object.keys(customFoods);
  if (keys.length === 0) { alert("No custom foods to remove."); return; }
  const list = keys.map((k,i) => `${i+1}. ${k}`).join("\n");
  const choice = prompt("Select a food to remove:\n" + list);
  if (!choice) return;
  const idx = parseInt(choice,10)-1;
  if (isNaN(idx) || idx < 0 || idx >= keys.length) { alert("Invalid choice."); return; }
  const key = keys[idx];
  delete customFoods[key];
  delete foodNutrients[key];
  saveCustomFoods(customFoods);
  populateFoodOptions();
  alert(key + " removed.");
}

/* Chart */
let carbChart, proteinChart, fatChart;

function drawCharts(carbs, protein, fats) {
  const carbLimit = recommendedLimits.carbs;
  const proteinLimit = recommendedLimits.protein;
  const fatLimit = recommendedLimits.fats;

  const chartOptions = (label, value, limit, color) => ({
    type: 'doughnut',
    data: {
      datasets: [{
        data: [value, Math.max(limit - value, 0)],
        backgroundColor: [color, '#eaeaea'],
        borderWidth: 0
      }]
    },
    options: {
      cutout: '75%',
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { enabled: false }
      }
    },
    plugins: [{
      id: 'centerText',
      beforeDraw(chart) {
        const { width, height, ctx } = chart;
        ctx.save();
        ctx.font = `${(height / 8).toFixed(0)}px Arial`;
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillStyle = color;
        ctx.fillText(`${value.toFixed(1)}/${limit}`, width / 2, height / 2);
        ctx.restore();
      }
    }]
  });

  // Destroy old charts
  if (carbChart) carbChart.destroy();
  if (proteinChart) proteinChart.destroy();
  if (fatChart) fatChart.destroy();

  carbChart = new Chart(document.getElementById("carbChart"), chartOptions("Carbs", carbs, carbLimit, "#06b6d4"));
  proteinChart = new Chart(document.getElementById("proteinChart"), chartOptions("Protein", protein, proteinLimit, "#f59e0b"));
  fatChart = new Chart(document.getElementById("fatChart"), chartOptions("Fats", fats, fatLimit, "#9333ea"));
}

/* Dark mode */
function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");

  // Save preference
  if (document.body.classList.contains("dark-mode")) {
    localStorage.setItem("theme", "dark");
  } else {
    localStorage.setItem("theme", "light");
  }
}

// Apply saved preference on load
document.addEventListener("DOMContentLoaded", () => {
  const savedTheme = localStorage.getItem("theme");
  if (savedTheme === "dark") {
    document.body.classList.add("dark-mode");
  }
});


// Floating menu wiring
document.addEventListener('DOMContentLoaded', () => {
  const wrap = document.getElementById('fabMenu');
  const btn  = document.getElementById('fabBtn');
  if (!wrap || !btn) return;

  btn.addEventListener('click', (e) => {
    e.stopPropagation();
    wrap.classList.toggle('show');
  });

  document.addEventListener('click', () => wrap.classList.remove('show'));
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') wrap.classList.remove('show');
  });
});

// Optional: simple custom-range fallback if you don't have a picker yet
function openCustomRange(){
  if (typeof openCustomReportPicker === 'function') {
    return openCustomReportPicker(); // your modal if implemented
  }
  const from = prompt('Start date (YYYY-MM-DD)');
  const to   = from && prompt('End date (YYYY-MM-DD)');
  if (from && to && typeof showCustomRangeReport === 'function') {
    showCustomRangeReport(from, to);
  }
}

// Show notification helper
function showNotification(title, message) {
  if (Notification.permission === "granted") {
    new Notification(title, {
      body: message,
      icon: "calorie icon_imresizer.png"
    });
  }
}

// Request permission on app open
document.addEventListener("DOMContentLoaded", () => {
  if (!("Notification" in window)) {
    console.log("This browser does not support notifications.");
    return;
  }

  if (Notification.permission === "default") {
    Notification.requestPermission();
  }

  // Schedule reminders
  scheduleDailyReminders();
});

// Function to schedule breakfast/lunch/dinner
function scheduleDailyReminders() {
  // Check current time
  const now = new Date();

  // Define reminder times (24h format)
  const reminders = [
    { hour: 9,  minute: 0,  title: "🍳 Breakfast Reminder", msg: "Log your breakfast calories!" },
    { hour: 13, minute: 33,  title: "🥗 Lunch Reminder",     msg: "Don’t forget to log your lunch!" },
    { hour: 20, minute: 0,  title: "🍽️ Dinner Reminder",    msg: "Log your dinner calories!" },
    { hour: 21, minute: 0,  title: "🌙 Bedtime Reminder",    msg: "Last chance to log your calories for today!" }
  ];

  reminders.forEach(reminder => {
    scheduleNotification(reminder.hour, reminder.minute, reminder.title, reminder.msg);
  });
}

// ---------------------------
// Welcome Notification
// ---------------------------
function showWelcomeNotification() {
  if (Notification.permission === "granted") {
    new Notification("👋 Welcome Back!", {
      body: "Let’s track your meals & stay healthy today 💪",
      icon: "calorie icon_imresizer.png."
    });
  }
}

// Trigger on app open
document.addEventListener("DOMContentLoaded", () => {
  if (!("Notification" in window)) return;

  if (Notification.permission === "granted") {
    showWelcomeNotification();
  } else if (Notification.permission === "default") {
    Notification.requestPermission().then((perm) => {
      if (perm === "granted") showWelcomeNotification();
    });
  }
});

// Helper to calculate delay until reminder time
function scheduleNotification(hour, minute, title, msg) {
  const now = new Date();
  let target = new Date();

  target.setHours(hour, minute, 0, 0);

  // If time already passed today → schedule for tomorrow
  if (target <= now) {
    target.setDate(target.getDate() + 1);
  }

  const delay = target - now;

  // Schedule first notification
  setTimeout(() => {
    showNotification(title, msg);

    // Repeat every 24h
    setInterval(() => {
      showNotification(title, msg);
    }, 24 * 60 * 60 * 1000);

  }, delay);
}

// ---------------------------
// Exercise Logging
// ---------------------------
let exerciseEntries = JSON.parse(localStorage.getItem("exerciseEntries")) || [];

const exerciseCalories = {
  running: 10,   // kcal per min
  cycling: 8,
  swimming: 11,
  yoga: 4,
  gym: 9
};
// excercise initial

function addExercise() {
  const type = document.getElementById("exercise").value;
  const duration = parseInt(document.getElementById("duration").value);

  if (!duration || duration <= 0) {
    alert("Enter a valid duration.");
    return;
  }

  const burned = exerciseCalories[type] * duration;
  const date = new Date().toISOString().split("T")[0]; // ✅ consistent with food

  const newEntry = { type, duration, burned, date };
  exerciseEntries.push(newEntry);

  localStorage.setItem("exerciseEntries", JSON.stringify(exerciseEntries));

  displayExercise();
  showResults();
}

function displayExercise() {
  const container = document.getElementById("exercise-entries");
  if (!container) return;
  if (exerciseEntries.length === 0) {
    container.innerHTML = "<h3>💪 Exercises</h3><div class='card'>No exercises yet.</div>";
    return;
  }
  container.innerHTML = "<h3>💪 Exercises</h3>";

  exerciseEntries.forEach((ex, i) => {
    const div = document.createElement("div");
    div.className = "entry";
    div.innerHTML = `
      <span>${ex.date} → ${ex.type} (${ex.duration} min) - 🔥 ${ex.burned} kcal</span>
      <button onclick="removeExercise(${i})">❌</button>
    `;
    container.appendChild(div);
  });
}

function removeExercise(index) {
  exerciseEntries.splice(index, 1);
  localStorage.setItem("exerciseEntries", JSON.stringify(exerciseEntries));
  displayExercise();
  showResults();
}

// ✅ Load exercises + start step counter on startup
document.addEventListener("DOMContentLoaded", () => {
  displayExercise();
  startStepCounter();   // 👈 this makes steps tracking automatic
});


// ---------------------------
// Step Counter (Accelerometer)
// ---------------------------
let stepCount = 0;
let lastStepTime = 0;

function startStepCounter() {
  if (typeof DeviceMotionEvent.requestPermission === "function") {
    // iOS (needs permission)
    DeviceMotionEvent.requestPermission()
      .then(response => {
        if (response === "granted") {
          window.addEventListener("devicemotion", stepHandler);
        } else {
          alert("Motion permission denied.");
        }
      })
      .catch(console.error);
  } else {
    // Android Chrome
    window.addEventListener("devicemotion", stepHandler);
  }
}

function stepHandler(event) {
  const acc = event.accelerationIncludingGravity;
  if (!acc) return;

  const magnitude = Math.sqrt(acc.x * acc.x + acc.y * acc.y + acc.z * acc.z);
  const now = Date.now();

  // threshold + debounce
  if (magnitude > 12 && now - lastStepTime > 300) {
    stepCount++;
    lastStepTime = now;
    updateStepDisplay();

    // also log calories burned from steps
    const burned = stepsToCalories(1); // 1 step = ~0.04 kcal
    const today = new Date().toISOString().split("T")[0];

    // Find if "steps" entry exists for today
    let existing = exerciseEntries.find(e => e.date === today && e.type === "steps");
    if (existing) {
      existing.burned += burned;
    } else {
      exerciseEntries.push({ type: "steps", duration: 0, burned, date: today });
    }

    localStorage.setItem("exerciseEntries", JSON.stringify(exerciseEntries));
    showResults(); // refresh report
  }
}

function updateStepDisplay() {
  const container = document.getElementById("step-counter");
  if (container) {
    container.innerHTML = `👟 Steps: ${stepCount}`;
  }
}

function stepsToCalories(steps) {
  return steps * 0.04; // avg kcal per step
}

// ---------------------------
// Loading Screen Progress
// ---------------------------
window.addEventListener("load", () => {
  const loader = document.getElementById("loading-screen");
  const progress = document.querySelector(".progress");

  if (loader && progress) {
    let width = 0;
    const interval = setInterval(() => {
      width += 2; // increase 2% each step
      if (width > 100) width = 100;
      progress.style.width = width + "%";
    }, 150); // every 150ms

    // Hide loader after 8 seconds
    setTimeout(() => {
      clearInterval(interval);
      loader.style.opacity = "0";
      setTimeout(() => loader.style.display = "none", 500);
    }, 8000);
  }
});


// ✅ Run after DOM is ready
document.addEventListener("DOMContentLoaded", () => {
  populateFoodOptions();   // fill dropdown on load
  displayEntries();        // load saved entries
  displayExercise();       // load exercises
  startStepCounter();      // steps auto start
});

document.addEventListener("DOMContentLoaded", () => {
  // Load latest foods each time home opens
  customFoods = loadCustomFoods();  
  foodNutrients = { ...baseFoodNutrients, ...customFoods };

  populateFoodOptions();   // refresh dropdown
  displayEntries();        // show saved entries
  displayExercise();       // show exercises
  startStepCounter();      // steps tracking
});

// ---------------------------
// Loading Screen Quotes + Version
// ---------------------------
const quotes = [
  "💪 Push harder than yesterday if you want a different tomorrow.",
  "🔥 Small steps every day lead to big results.",
  "🥗 Eat better, feel better, live better.",
  "🚴‍♂️ One workout at a time, one meal at a time.",
  "🌟 Progress, not perfection.",
  "🏃‍♀️ Your only limit is you.",
  "🥇 Don’t count the days, make the days count."
];

const APP_VERSION = "v1.0.0"; // change when you update your app

document.addEventListener("DOMContentLoaded", () => {
  // Pick a random quote
  const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
  const quoteEl = document.getElementById("loading-quote");
  if (quoteEl) quoteEl.textContent = randomQuote;

  // Show version
  const versionEl = document.getElementById("app-version");
  if (versionEl) versionEl.textContent = APP_VERSION;
});

// Auto-save daily report at midnight
// ---------------------------
// Auto-save Daily Report at Midnight
// ---------------------------
function scheduleMidnightSave() {
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setHours(24, 0, 0, 0); // midnight
  const msUntilMidnight = tomorrow - now;

  setTimeout(() => {
    finalizeTodayReport();
    scheduleMidnightSave(); // schedule again for next midnight
  }, msUntilMidnight);
}

function finalizeTodayReport() {
  const today = new Date().toISOString().split("T")[0];
  let totals = { calories: 0, carbs: 0, protein: 0, fats: 0, burned: 0 };

  // sum today’s foods
  entries.forEach(({ food, quantity, date }) => {
    if (date !== today) return;
    const item = foodNutrients[food];
    if (!item) return;

    if (item.calories_per_gram) {
      totals.calories += item.calories_per_gram * quantity;
      totals.carbs += (item.carbs || 0) * quantity;
      totals.protein += (item.protein || 0) * quantity;
      totals.fats += (item.fats || 0) * quantity;
    } else {
      totals.calories += (item.calories || 0) * quantity;
      totals.carbs += (item.carbs || 0) * quantity;
      totals.protein += (item.protein || 0) * quantity;
      totals.fats += (item.fats || 0) * quantity;
    }
  });

  // sum today’s exercise
  (exerciseEntries || []).forEach(({ burned, date }) => {
    if (date === today) totals.burned += burned;
  });

  totals.net = totals.calories - totals.burned;

  // save report
  const reports = loadReports();
  reports[today] = totals;
  saveReports(reports);

  // clear today’s entries
  entries = [];
  exerciseEntries = [];
  localStorage.setItem("entries", JSON.stringify(entries));
  localStorage.setItem("exerciseEntries", JSON.stringify(exerciseEntries));

  console.log("✅ Daily report saved at midnight:", today, totals);

  // --- Reset display for new day ---
  showResults();     // refresh report UI
  displayEntries();  // clear food list
  displayExercise(); // clear exercise list
}

document.addEventListener("DOMContentLoaded", () => {
  scheduleMidnightSave();

  // ensure today’s report exists in storage
  const today = new Date().toISOString().split("T")[0];
  const reports = loadReports();
  if (!reports[today]) {
    reports[today] = { calories: 0, carbs: 0, protein: 0, fats: 0, burned: 0, net: 0 };
    saveReports(reports);
  }

  // show today immediately on load
  showResults();
});



